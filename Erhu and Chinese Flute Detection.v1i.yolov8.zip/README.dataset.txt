# Erhu and Chinese Flute Detection > 2025-01-01 7:13pm
https://universe.roboflow.com/2025jankopio/erhu-and-chinese-flute-detection

Provided by a Roboflow user
License: Public Domain

